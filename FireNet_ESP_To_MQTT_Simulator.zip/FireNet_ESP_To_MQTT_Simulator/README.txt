FireNet ESP8266-To-MQTT Simulator

Overview
The FireNet MQTT Simulator is a Windows application that simulates an MQTT client in the FireNet fire detection network. It allows users to manually send emergency and non-emergency messages to devices subscribed to an MQTT topic.

System Requirements
- Windows 11 (64-bit)
- Network connection to the computer hosting the FireNet MQTT broker
- Broker IP address or hostname
- Valid MQTT username and password
- Microsoft Visual C++ Redistributable (x64), if not already installed

Microsoft Visual C++ Redistributable:
https://aka.ms/vc14/vc_redist.x64.exe

Installation
1. Extract all files from the ZIP into a folder
2. If Windows reports a missing Visual C++ runtime, install the redistributable linked above (or the file included in this zip named "VC_redist.x64.exe")
3. Double-click `FireNetSimulator.exe` to launch the application

Do not separate the executable from its accompanying DLL files

Connecting to FireNet
When the application starts, enter the following settings:

- Broker IP/hostname: The IP address or hostname of the computer running Mosquitto
- Port: Default is `1883`
- Client ID: A unique ID is generated automatically by default
- Username: Default is `firenet_user`
- Password: Enter the password provided by the MQTT set up document
- MQTT topic: Default is `firenet`.

Press Enter to accept a displayed default value, which will be surrounded by brackets.

Sending Messages

After successfully connecting, the application displays three options:

1. Send FIRE ALERT: Publishes an emergency message.
2. Send NORMAL STATUS: Publishes a non-emergency message.
3. Disconnect and Exit: Disconnects from the broker and closes the application.

Example messages

Fire alert:
`{"alert":1,"message":"Fire detected!"}`

Normal status:
`{"alert":0,"message":"Temperature normal."}`

Messages are published with MQTT QoS 1.

Troubleshooting

Unable to connect
- Verify the broker IP address and port.
- Confirm that the broker is running.
- Ensure TCP port 1883 is allowed through the broker computer's firewall.
- Make sure both computers can communicate over the network.

Authentication failed
- Verify the MQTT username and password.

Messages are not appearing on receiving devices
- Verify that the receiving device is connected to the same broker.
- Confirm that it is subscribed to the same topic entered in the simulator.

Missing DLL or runtime error
- Keep all supplied DLL files in the same folder as `FireNetSimulator.exe`.
- Install the Microsoft Visual C++ Redistributable (x64) if required.

Security Note
This project configuration uses unencrypted MQTT over TCP port 1883. Only use it on a trusted network for project testing.